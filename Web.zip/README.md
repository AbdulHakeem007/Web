# SE-351L Web Engineering Lab - Complete Solutions

**Student:** Hafsa Nayyab  
**Course:** BS Software Engineering  
**Institution:** Ghulam Ishaq Khan Institute (GIKI)  
**Session:** Spring 2026

---

## 📚 Lab Contents

| Lab | Topic | Files |
|-----|-------|-------|
| **Lab 1** | HTML5 Basics & Structure | `task1_student_profile.html`, `task2_complete_portfolio.html` |
| **Lab 2** | HTML5 Elements (Anchor, Table, Forms, Div) | `task1_profile_complete.html` |
| **Lab 3** | CSS3 & Responsive Design | `task1_coding_website.html`, `task1_style.css` |
| **Lab 4** | JavaScript Functions | `task1_dynamic_webpage.html`, `task2_calculator.html`, `task3_student_management.html`, `task4_external_events.html`, `task4_external.js` |
| **Lab 5** | JavaScript & DOM Animation | `task1_addition_form.html`, `task2_dropdown_replace.html`, `task3_form_validation.html`, `task4_text_selection.html`, `task5_bike_dealer.html`, `task6_photo_album.html` |
| **Lab 6** | PHP Introduction, Variables & Sessions | `shop.php`, `cart.php` |
| **Lab 7** | Cloud & Deployment | `deployment_guide.md` |
| **Lab 8** | Python & Django | `lab8_setup.md` |
| **Lab 9** | Django Interface and Project | `lab9_project.md` |
| **Lab 10** | Database Models & Data Management | `lab10_blog_system.md` |
| **Lab 11** | Authentication, AI Integration & Deployment | `lab11_complete_system.md` |
| **Lab 12** | Open Ended Lab (Final Project) | `lab12_final_project.md` |

---

## 🚀 Quick Start

### HTML/CSS/JS Labs (1-5)
Simply open the `.html` files in any web browser.

```bash
# Example
open Lab1_HTML5_Basics/task1_student_profile.html
```

### PHP Lab (6)
Requires PHP server (XAMPP/WAMP):
```bash
# Place files in htdocs and visit
http://localhost/Lab6_PHP_Sessions/shop.php
```

### Django Labs (8-12)
```bash
# Install Django
pip install django

# Create project and follow guides in .md files
django-admin startproject myproject
```

---

## 📁 Repository Structure

```
SE-351L-Web-Engineering/
├── Lab1_HTML5_Basics/
│   ├── task1_student_profile.html
│   └── task2_complete_portfolio.html
├── Lab2_HTML5_Elements/
│   └── task1_profile_complete.html
├── Lab3_CSS3_Responsive/
│   ├── task1_coding_website.html
│   └── task1_style.css
├── Lab4_JavaScript_Basics/
│   ├── task1_dynamic_webpage.html
│   ├── task2_calculator.html
│   ├── task3_student_management.html
│   ├── task4_external_events.html
│   └── task4_external.js
├── Lab5_JS_DOM_Animation/
│   ├── task1_addition_form.html
│   ├── task2_dropdown_replace.html
│   ├── task3_form_validation.html
│   ├── task4_text_selection.html
│   ├── task5_bike_dealer.html
│   └── task6_photo_album.html
├── Lab6_PHP_Sessions/
│   ├── shop.php
│   └── cart.php
├── Lab7_Cloud_Deployment/
│   └── deployment_guide.md
├── Lab8_Python_Django/
│   └── lab8_setup.md
├── Lab9_Django_Interface/
│   └── lab9_project.md
├── Lab10_Database_Models/
│   └── lab10_blog_system.md
├── Lab11_Auth_AI_Deploy/
│   └── lab11_complete_system.md
└── Lab12_Open_Ended/
    └── lab12_final_project.md
```

---

## 📝 Lab Details

### Lab 1: HTML5 Basics
- Basic tags: headings, paragraphs, lists, images
- Text formatting: bold, italic, underline
- Semantic HTML5 elements: header, nav, section, article, aside, footer

### Lab 2: HTML5 Elements
- Anchor links with target attributes
- Tables with border, headers, data
- Forms with all input types
- Dropdown menus (select/option)
- Buttons and div containers

### Lab 3: CSS3 Responsive Design
- "Coding is Poetry" website
- Flexbox and Grid layouts
- Media queries for mobile/tablet/desktop
- Linear gradients, hover effects
- Search box with icon

### Lab 4: JavaScript Basics
- innerHTML vs innerText demonstration
- Dynamic font size control
- Interactive calculator with validation
- Student management with objects and arrays
- External JS with multiple event handlers
- Script placement comparison (head vs body)
- const object immutability demo

### Lab 5: DOM Animation & Events
- Addition form with NaN handling
- Dropdown replacement with textbox
- Form validation with red error messages
- Text selection display using onSelect
- Bike dealer form with alert validation
- Photo album with category filtering

### Lab 6: PHP Sessions
- Shopping cart using `$_SESSION`
- Arrays for storing cart items
- Add to cart, remove item, clear cart
- Total price calculation

### Lab 7: Cloud Deployment
- IaaS vs PaaS vs SaaS comparison
- GitHub + Netlify deployment steps
- GitHub Pages alternative
- Documentation checklist

### Lab 8: Python & Django
- Python lists and dictionaries
- Django installation and setup
- Project and app creation
- Development server

### Lab 9: Django Interface
- MVT architecture
- Templates and template inheritance
- Static files configuration
- URL routing and views
- Complete portfolio website

### Lab 10: Database Models
- Author → Post → Comment relationships
- One-to-Many ForeignKeys
- CRUD operations
- Business rules: max 5 comments, draft blocking
- Cascade deletion

### Lab 11: Authentication & AI
- User registration with password hashing
- Login/logout with sessions
- @login_required decorators
- OpenAI GPT integration
- Security settings for production
- Heroku deployment

### Lab 12: Final Project
- Complete blog system
- Protected routes (create/update/delete)
- Public read access
- Comment system
- Author-only edit/delete

---

## 🛠️ Technologies Used

- **Frontend:** HTML5, CSS3, JavaScript (ES6+)
- **Backend:** PHP, Python, Django
- **Database:** SQLite (Django ORM)
- **Deployment:** GitHub, Netlify, Heroku
- **AI:** OpenAI GPT API

---

## 📧 Contact

**Hafsa Nayyab**  
Faculty of Computer Science and Engineering  
Ghulam Ishaq Khan Institute, Pakistan

---

*This repository contains complete solutions for SE-351L Web Engineering Lab course.*
